#include "server.h"

#include <QDebug>
#include <QMutex>
#include <QSettings>
#include <QApplication>
#include <QTextCodec>
#include <QtGui/QCursor>

extern QMutex g_bufferLocker_;
extern QList<QByteArray> g_BufferList_;

#define SERVER_PORT 44444

Server::Server(QObject *parent)
	: QObject(parent),
	isLockMouse_(false),
	lockTimes_(0)
{
	server_ = new QTcpServer();
	if (!server_->listen(QHostAddress::Any, SERVER_PORT))
	{
		qDebug() << QString::fromLocal8Bit("senderThread start err.") << server_->errorString();
	}
	connect(server_, SIGNAL(newConnection()), this, SLOT(clinetConnected()));

	connect(&timer_, SIGNAL(timeout()), this, SLOT(sendData()));
	timer_.start(20);
}

Server::~Server()
{

}

void Server::clinetConnected()
{
	QTcpSocket *camera = server_->nextPendingConnection();
	QString ip = camera->peerAddress().toString();
	QString port = QString().setNum(camera->peerPort());

	QString clientName = ip + ":" + port;
	clientMap_[clientName] = camera;

	connect(camera, SIGNAL(disconnected()), this, SLOT(removeClient()));

	connect(camera, SIGNAL(readyRead()), this, SLOT(clientIncomingMsg()));

	qDebug() << "********* add client :" << clientName << "client's size:" << clientMap_.size() << "********* ";
}

void Server::removeClient()
{
	QTcpSocket* client = (QTcpSocket *)sender();

	QString ip = client->peerAddress().toString();
	QString port = QString().setNum(client->peerPort());
	QString cameraName = ip + ":" + port;

	if (clientMap_.contains(cameraName))
	{
		clientMap_.remove(cameraName);
	}

	qDebug() << "********* remove client :" << cameraName << "client's size:" << clientMap_.size() << "********* ";
}

void Server::clientIncomingMsg()
{
	QByteArray intbytes;
	QTcpSocket* tcpSocket_ = (QTcpSocket*)sender();
	QHostAddress address = tcpSocket_->peerAddress();
	QString ip = address.toString();
	quint16 portnum = tcpSocket_->peerPort();
	QString port = QString().setNum(portnum);
	QString clientName = ip + ":" + port;
	if (tcpSocket_->bytesAvailable() < (int)sizeof(quint16))
	{
		return;
	}

	quint64 blockSize = tcpSocket_->bytesAvailable();
	QByteArray tcpbuffer = tcpSocket_->read(blockSize);
	qDebug() << clientName << tcpbuffer.toHex();
}

void Server::sendData()
{
	if (isLockMouse_)
	{
		lockTimes_++;
		if (lockTimes_ > 3000)
		{
			isLockMouse_ = false;
			lockTimes_ = 0;
		}

		lockMouse();
	}
	else
	{
		lockTimes_ = 0;
	}

	QByteArray data;
	g_bufferLocker_.lock();
	if (g_BufferList_.size() > 0)
	{
		data = g_BufferList_.takeFirst();
	}
	g_bufferLocker_.unlock();

	if (data.length() > 0 && clientMap_.size()>0)
	{
		QList<QTcpSocket*> clients = clientMap_.values();
		for each (QTcpSocket* client in clients)
		{
			quint32 length = data.size();
			
			//size
			QByteArray array;
			array.setRawData((char*)&(length), sizeof(length));
			data.prepend(array);

			//header
			data.prepend("ZX");

			quint64 size = client->write(data);
			//qDebug() << "write size:" << size << " ip:" << client->peerAddress().toString();
		}
	}
}


void Server::setAutoStart()
{
	QString sApp = QApplication::applicationFilePath();//�ҵĳ�������
	sApp.replace("/", "\\");
	QSettings *setting = new QSettings("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion", QSettings::NativeFormat);

	QTextCodec *codec = QTextCodec::codecForName("GBK");
	setting->setIniCodec(codec);

	//�����Զ�����
	setting->beginGroup("Run");
	setting->setValue("Monitor.exe", QVariant(sApp));
	setting->endGroup();

	delete setting;
	setting = NULL;
}

void Server::stopAutoStart()
{
	QString sApp = QApplication::applicationFilePath();//�ҵĳ�������
	sApp.replace("/", "\\");
	QSettings *setting = new QSettings("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion", QSettings::NativeFormat);

	QTextCodec *codec = QTextCodec::codecForName("GBK");
	setting->setIniCodec(codec);

	//ȡ�������Զ�����
	setting->beginGroup("Run");
	setting->remove("Monitor.exe");
	setting->endGroup();

	delete setting;
	setting = NULL;
}

bool Server::GetIsAutoStart()
{
	QSettings *setting = new QSettings("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", QSettings::NativeFormat);
	QStringList keyList = setting->childKeys();
	delete setting;
	setting = NULL;

	if (keyList.contains(QString::fromLocal8Bit("Monitor.exe")))
	{
		return true;
	}

	return false;
}

void Server::lockMouse()
{
	//QPoint pos = QCursor::pos();
	//pos.setX(pos.x());
	//pos.setY(pos.y());
	QCursor::setPos(QPoint(0,0));
}

void Server::lockerMouseSlot(bool isLock)
{
	isLockMouse_ = isLock;
}
