#ifndef DRESSWIN_H
#define DRESSWIN_H

#include <QWidget>
#include <QPainter>
#include <QPushButton>
#include <QButtonGroup>
#include <QWheelEvent>

const int NUM = 8;//装扮数量

namespace Ui
{
    class DressWin;
}

class DressWin : public QWidget
{
    Q_OBJECT

public:
    explicit DressWin(QWidget* parent = nullptr);
    ~DressWin();
    void accept(std::vector<QPixmap>& body, std::vector<QPixmap>& ears, int bodyNum, int earsNum);
signals:
    void bodyChangeNum(int id);
    void earsChangeNum(int id);
private slots:
    void bodyChange(int Id);
    void earsChange(int Id);
private:
    Ui::DressWin* ui;
    QPushButton* bodyBtn[NUM], *earsBtn[NUM];  //各部件对应按钮
    QButtonGroup* bodyBox, *earsBox;           //按钮组
    std::vector<QPixmap> body, ears; //各部件对应图片容器
    int y;  // 滚动
    void paintEvent(QPaintEvent*);
    void wheelEvent(QWheelEvent* ev);
    void initBtn();

};

#endif // DRESSWIN_H
