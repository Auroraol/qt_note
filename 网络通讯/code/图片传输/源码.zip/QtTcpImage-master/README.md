# QtTcpImage

# 1 简介
这是一个用Qt实现的TCP传输图片，图片编码为base64进行传输。
详细介绍：https://fanxinglanyu.blog.csdn.net/article/details/105437582
