#ifndef HARO_H
#define HARO_H

#include <QWidget>
#include <QSettings>
#include <vector>
#include <QLabel>
#include <QSystemTrayIcon>
#include <QMenu>
#include <QCloseEvent>
#include <QAction>
#include <QMouseEvent>
#include <QCalendarWidget>
#include "setwin.h"
#include "dresswin.h"
#include "gamewin.h"
#include "about.h"
#include "musicwindow/onemusic.h"

using namespace std;

QT_BEGIN_NAMESPACE
namespace Ui
{
    class Haro;
}
QT_END_NAMESPACE

class Haro : public QWidget
{
    Q_OBJECT

public:
    Haro(QWidget* parent = nullptr);
    ~Haro();

signals:
    void getSize(int size);

protected slots:

private slots:
    void OnSystemTrayClicked(QSystemTrayIcon::ActivationReason reason);
    void actionTriggered(QAction* action);
    void animation();
    void on_pushButton_closeBtn_clicked();

    void on_pushButton_dressBtn_clicked();

    void on_pushButton_moreBtn_clicked();

    void on_pushButton_minBtn_clicked();

    void on_pushButton_setBtn_clicked();

    void on_pushButton_musicBtn_clicked();

    void on_pushButton_gameBtn_clicked();

    void on_pushButton_calenBtn_clicked();

    void changeSize(int value);
    void sizeUpdate(int value);
private:
    Ui::Haro* ui;
    QSettings* settings;
    int size;
    int btnSize;
    int bodyNum, earsNum;
    vector<QPixmap> body, ears1, ears2; //各部件对应图片容器
    QPixmap eyes, stripe;               //眼睛遮罩

    QMenu* m_trayMenu;   // 系统托盘
    QSystemTrayIcon* m_tray;

    //
    vector<QPixmap> movement; //表情图片容器
    vector<int>faceNum;       //每个表情对应帧数与起始位置
    vector<QPixmap> spMovement; //error动作图片容器

    int face;//表情序号
    int faceSum;//表情数量
    int spMove;  //error动作序号



    // 位置
    bool        m_bDrag;
    QPoint      mouseStartPoint;
    QPoint      windowTopLeftPoint;

    //
    SetWin* setWindow;
    DressWin* dressWindow;
    QCalendarWidget* calenWindow;
    GameWin* gameWindow;
    About* aboutWindow;
    OneMusic* musicWindow;   // 音乐播发器


    void loadSettings();
    void saveSettings();
    virtual void closeEvent(QCloseEvent* event);
    void loadImage();
    void loadIAressmage();
    void imageSet(QLabel* image, QPixmap map);
    void addSystemTray();
    void initBtn();
    void buttonSize();
    void initHaro();
    void loadImageAnimationImage();
    void specialMovementLoad();
    void specialMovement();
    void mousePressEvent(QMouseEvent* ev);
    void mouseMoveEvent(QMouseEvent* ev);
    void wheelEvent(QWheelEvent* ev);
    void mouseReleaseEvent(QMouseEvent* event);


    void setqssstyle(const QString& qssFile);
};
#endif // HARO_H
