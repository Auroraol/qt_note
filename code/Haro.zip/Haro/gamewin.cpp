#include "gamewin.h"
#include "ui_gamewin.h"
#include <QBitmap>
#include <QPainter>
#include <QUrl>
#include <qdesktopservices.h>

GameWin::GameWin(QWidget* parent) :
    QWidget(parent),
    ui(new Ui::GameWin)
{
    ui->setupUi(this);
//    setAutoFillBackground(true);
    setAttribute(Qt::WA_StyledBackground);   // 设置顶层窗口有效
    setWindowIcon(QIcon(":/images/icon/game.png"));
    setWindowTitle("游戏");
    setWindowOpacity(0.98);//设置透明度
    // 保持窗口置顶 + 去除边框
    Qt::WindowFlags m_flags = windowFlags();
    setWindowFlags(m_flags | Qt::WindowStaysOnTopHint | Qt::FramelessWindowHint);
    //设置圆角边框
    QBitmap bmp(this->size());
    bmp.fill();
    QPainter p(&bmp);
    p.setPen(Qt::NoPen);
    p.setBrush(Qt::black);
    p.drawRoundedRect(bmp.rect(), 20, 20);
    setMask(bmp);
}

GameWin::~GameWin()
{
    delete ui;
}

void GameWin::on_pushButton_clicked()
{
    QString URL = "https://leetcode.cn/problems/median-of-two-sorted-arrays/";
    QDesktopServices::openUrl(QUrl(URL.toLatin1()));
}

