#ifndef GAMEWIN_H
#define GAMEWIN_H

#include <QWidget>

namespace Ui
{
    class GameWin;
}

class GameWin : public QWidget
{
    Q_OBJECT

public:
    explicit GameWin(QWidget* parent = nullptr);
    ~GameWin();

private slots:
    void on_pushButton_clicked();

private:
    Ui::GameWin* ui;
};

#endif // GAMEWIN_H
