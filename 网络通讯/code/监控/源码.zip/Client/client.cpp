#include "client.h"

#include <QMessagebox>
#include <QHostAddress>
#include <QDir>

#define SERVER_PORT 44444
#define UDP_CLIENT_PORT 44448
#define UDP_SERVER_PORT 44446

Client::Client(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);

	isConnected_ = false;
	isRecord_ = false;

	socket_ = new QTcpSocket();
	socket_->setSocketOption(QAbstractSocket::LowDelayOption, 1);
	connect(socket_, SIGNAL(readyRead()), this, SLOT(readFortune()));
	connect(socket_, SIGNAL(error(QAbstractSocket::SocketError)), this, SLOT(displayError(QAbstractSocket::SocketError)));
	connect(socket_, SIGNAL(stateChanged(QAbstractSocket::SocketState)), this, SLOT(stateChanged(QAbstractSocket::SocketState)));

	udpSocket_ = new QUdpSocket(this);
	udpSocket_->bind(UDP_CLIENT_PORT,QUdpSocket::ShareAddress);
	connect(udpSocket_, SIGNAL(readyRead()), this, SLOT(readPendingDatagrams()));

	connect(&timer_, SIGNAL(timeout()), this, SLOT(serverTimeOut()));
	timer_.start(5000);

	ui.lineEdit_ip->setText("192.168.");

	showMaximized();
}

Client::~Client()
{

}

void Client::connectServer(QString ip)
{
	socket_->abort();
	receiveData_.clear();

	socket_->connectToHost(QHostAddress(ip), SERVER_PORT);

	ui.lineEdit_ip->setText(ip);
}

void Client::readFortune()
{
	quint64 bytesAvailable = socket_->bytesAvailable();
	if (bytesAvailable <= 0)
		return;

	QByteArray data = socket_->read(bytesAvailable);
	//qDebug() << "from:" << socket_->peerAddress().toString() << " size:" << data.size();
	receiveData_.append(data);

	processData();
}

void Client::displayError(QAbstractSocket::SocketError socketError)
{
	switch (socketError) {
	case QAbstractSocket::RemoteHostClosedError:
		break;
	case QAbstractSocket::HostNotFoundError:
		QMessageBox::information(this, tr("Fortune Client"),
			tr("The host was not found. Please check the "
			"host name and port settings."));

		break;
	case QAbstractSocket::ConnectionRefusedError:
		QMessageBox::information(this, tr("Fortune Client"),
			tr("The connection was refused by the peer. "
			"Make sure the fortune server is running, "
			"and check that the host name and port "
			"settings are correct."));
		break;
	default:
		QMessageBox::information(this, tr("Fortune Client"),
			tr("The following error occurred: %1.")
			.arg(socket_->errorString()));
	}
}

void Client::stateChanged(QAbstractSocket::SocketState socketState)
{
	switch (socketState) {
	case QAbstractSocket::HostLookupState:
	case QAbstractSocket::ConnectingState:
		break;
	case QAbstractSocket::ConnectedState:
		isConnected_ = true;
		break;
	case QAbstractSocket::BoundState:
	case QAbstractSocket::ListeningState:
		break;
	case QAbstractSocket::ClosingState:
	case QAbstractSocket::UnconnectedState:
	{
		isConnected_ = false;
		isRecord_ = false;
		ui.pushButton_record->setText(QString::fromLocal8Bit("¼��"));
		break;
	}
	default:
		Q_ASSERT_X(0, "stateChanged", "Unknown socket state!");
	}
}

void Client::processData()
{
	
	int headerLength = sizeof(quint32) + 2;
	while (true)
	{
		if (receiveData_.size() <= headerLength)
			return;

		int totalLenth = receiveData_.length();
		if (receiveData_.at(0) == 'H' && receiveData_.at(1) == 'T')
		{
			//length
			int dataLength = 0;
			QByteArray  intbytes = receiveData_.mid(2, sizeof(dataLength));
			memcpy(&(dataLength), intbytes.data(), intbytes.size());
			
			if (totalLenth > headerLength + dataLength)
			{
				QByteArray picData = receiveData_.mid(headerLength, dataLength);
				qDebug() << QDateTime::currentDateTime();
				showPic_.loadFromData(picData);
				ui.label_show->setPixmap(showPic_);
				receiveData_.remove(0, headerLength + dataLength);
			}
			//qDebug() << "left length:" << receiveData_.length();
			return;
		}
		else
		{
			receiveData_.remove(0,1);
			qDebug() << "remove ";
		}
	}
}

void Client::processTheDatagram(QByteArray &datagram, QString ip, quint32 port)
{
	if (datagram.length() >= 2)
	{
		QByteArray midData = datagram.mid(0, 2);
		if (QString(midData).compare("ZX") == 0)
		{
			if (!serverIpMap_.contains(ip))
			{
				setList();
			}
			serverIpMap_[ip] = QDateTime::currentDateTime();
		}
	}
}

void Client::readPendingDatagrams()
{
	while (udpSocket_->hasPendingDatagrams()) {
		QByteArray datagram;
		datagram.resize(udpSocket_->pendingDatagramSize());
		QHostAddress sender;
		quint16 senderPort;
		udpSocket_->readDatagram(datagram.data(), datagram.size(), &sender, &senderPort);

		QString ip = formatIP(sender.toString());
		processTheDatagram(datagram, ip, senderPort);
	}
}


QString Client::formatIP(QString ip)
{
	QString str;

	if (ip.contains(":"))
	{
		QStringList tmpList = ip.split(":");
		foreach(QString tmp, tmpList)
		{
			if (tmp.contains("."))
			{
				str = tmp;
				break;
			}
		}
	}
	else
	{
		str = ip;
	}

	return str;
}

void Client::setList()
{
	ui.listWidget->clear();
	if (serverIpMap_.size() > 0)
	{
		ui.listWidget->addItems(serverIpMap_.keys());
	}
}

void Client::on_list_dbclicked(const QModelIndex& index)
{
	if (!index.isValid())
		return;

	QString ip = ui.listWidget->item(index.row())->data(0).toString();
	connectServer(ip);
}

void Client::serverTimeOut()
{
	QStringList ips = serverIpMap_.keys();
	QDateTime curT = QDateTime::currentDateTime();
	foreach(QString ip, ips)
	{
		if (serverIpMap_[ip].secsTo(curT) > 20)
		{
			serverIpMap_.remove(ip);
		}
	}

	setList();
}

void Client::on_connect_clicked()
{
	QString ip = ui.lineEdit_ip->text();
	if (ip.split(".").size() != 4)
	{
		QMessageBox::information(NULL, "waring", "ip format error");
		return;
	}

	connectServer(ip);
}

void Client::on_record_clicked()
{
	if (isRecord_)
	{
		ui.pushButton_record->setText(QString::fromLocal8Bit("¼��"));
		isRecord_ = false;
	}
	else
	{
		if (isConnected_)
		{
			isRecord_ = true;
			ui.pushButton_record->setText(QString::fromLocal8Bit("ֹͣ¼��"));
		}
	}
}

void Client::on_playback_clicked()
{

}

void Client::on_getPic_clicked()
{
	if (!isConnected_)
	{
		return;
	}

	QString ip = ui.lineEdit_ip->text();
	QString path = QApplication::applicationDirPath();
	path += tr("/pic/");
	QDir dir(path);
	if (!dir.exists())
	{
		if (!(dir.mkdir(path)))
		{
			path == QString("C:\\");
		}
	}

	QString fileName = path + ip + " "+QDateTime::currentDateTime().toString("yyyy-MM-dd hh-mm-ss") + ".bmp";
	bool isok = showPic_.save(fileName);
	if (isok)
	{
		QMessageBox::information(NULL, QString::fromLocal8Bit("��ͼ��ʾ"), QString::fromLocal8Bit("����ɹ�\n%1").arg(fileName));
	}
}

void Client::on_lockMouse_clicked()
{
	QString ip = ui.lineEdit_ip->text();

	QByteArray message;
	QByteArray intbytes;

	//set header
	message.append('H');

	//set type
	message.append('L');

	//set is lock
	message.append('Y');

	//set tail
	message.append('T');

	udpSendData(ip, message);
}

void Client::on_unLockMouse_clicked()
{
	QString ip = ui.lineEdit_ip->text();

	QByteArray message;
	QByteArray intbytes;

	//set header
	message.append('H');

	//set type
	message.append('L');

	//set is lock
	message.append('N');

	//set tail
	message.append('T');

	udpSendData(ip, message);
}

void Client::udpSendData(QString ip, const QByteArray &data)
{
	udpSocket_->writeDatagram(data, QHostAddress(ip), UDP_SERVER_PORT);
}
