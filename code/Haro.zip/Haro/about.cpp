#include "about.h"
#include "ui_about.h"
#include <QIcon>

About::About(QWidget* parent) :
    QWidget(parent),
    ui(new Ui::About)
{
    ui->setupUi(this);
    Qt::WindowFlags m_flags = windowFlags();
    setWindowFlags( m_flags | Qt::WindowStaysOnTopHint);
    setWindowFlags(Qt::FramelessWindowHint);
    setWindowTitle(" ");
    setWindowIcon(QIcon(":/images/icon/about.ico"));
//    //去掉最大化、最小化按钮，保留关闭按钮
    setWindowFlags(Qt::WindowCloseButtonHint);
    setFixedSize(419, 519);
    QPixmap Pix(":/images/icon/haro_icon.ico");
    QSize PixSize = ui->label_2->size();
    Pix.scaled(PixSize, Qt::IgnoreAspectRatio);    // label而言
    ui->label_2->setScaledContents(true);
    ui->label_2->setPixmap(Pix);
}

About::~About()
{
    delete ui;
}
