#include "QtMusic.h"

#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QTimer>
#include <QPropertyAnimation>

QtMusic::QtMusic(QWidget *parent)
    : QMainWindow(parent),
	musicFileDir(QApplication::applicationDirPath() + "/musics"),
	downloadedMusicFileDir(QApplication::applicationDirPath() + "/downloaded"),
	player(new QMediaPlayer(this))
{
    ui.setupUi(this);
	initForm();
	initPageSong();
	signalSlotDefine();
}

void QtMusic::initForm()
{
	QString strDir = QCoreApplication::applicationDirPath() + "//" + "musics";
	QDir dir(strDir);

	if (!dir.exists())
		dir.mkdir(strDir);

}

void QtMusic::initPageSong()
{
	auto pTable = ui.tableWidgetSong;
	pTable->setMouseTracking(true);
	pTable->horizontalHeader()->setMinimumSectionSize(50);
	pTable->horizontalHeader()->setMaximumHeight(32);
	pTable->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
	pTable->verticalHeader()->setDefaultAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
	pTable->horizontalHeader()->setStretchLastSection(true);
	pTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
	pTable->setSelectionBehavior(QAbstractItemView::SelectRows);
	pTable->setSelectionMode(QAbstractItemView::SingleSelection);
}

void QtMusic::signalSlotDefine()
{
	connect(ui.tbnSearch, SIGNAL(clicked()), this, SLOT(slotOnSerach()));
	connect(ui.tableWidgetSong, SIGNAL(cellDoubleClicked(int, int)), this, SLOT(slotTableWidgetSongDoubleClicked(int, int)));

	connect(player, &QMediaPlayer::mediaStatusChanged, this, [=](QMediaPlayer::MediaStatus status)
	{
		if (status == QMediaPlayer::EndOfMedia)
		{
		}
		else if (status == QMediaPlayer::InvalidMedia)
		{
			qDebug() << QString::fromLocal8Bit("��Чý�壺") << playingSong.simpleString();
		}

	});

	connect(player, &QMediaPlayer::positionChanged, this, [=](qint64 position) 
	{
		ui.now_duration->setText(msecondToString(position));
		slotPlayerPositionChanged();
	});



	connect(player, &QMediaPlayer::durationChanged, this, [=](qint64 duration)
	{
		ui.playProgressSlider->setMaximum(static_cast<int>(duration));
	});
}

void QtMusic::slotOnSerach()
{
	QString strSongName = ui.lineEditSearch->text();
	if (strSongName.trimmed().isEmpty())
		return;

	QString url = "http://iwxyi.com:3000/search?keywords=" + strSongName.toUtf8().toPercentEncoding();
	QNetworkAccessManager* manager = new QNetworkAccessManager;
	QNetworkRequest* request = new QNetworkRequest(url);

	request->setHeader(QNetworkRequest::ContentTypeHeader, "application/x-www-form-urlencoded; charset=UTF-8");
	request->setHeader(QNetworkRequest::UserAgentHeader, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36");
	
	connect(manager, &QNetworkAccessManager::finished, this, [=](QNetworkReply* reply)
	{
		QByteArray data = reply->readAll();
		QJsonParseError error;
		QJsonDocument document = QJsonDocument::fromJson(data, &error);
		if (error.error != QJsonParseError::NoError)
		{
			qDebug() << error.errorString();
			return;
		}

		QJsonObject json = document.object();
		if (json.value("code").toInt() != 200)
		{
			qDebug() << ("���ؽ����Ϊ200��") << json.value("message").toString();
			return;
		}

		QJsonArray musics = json.value("result").toObject().value("songs").toArray();


		searchResultSongs.clear();
		foreach(QJsonValue val, musics)
			searchResultSongs << Music::fromJson(val.toObject());
			
		setSearchResultTable(searchResultSongs);

	});
	manager->get(*request);
}

/**
 * �������ݽ����Table
 */
void QtMusic::setSearchResultTable(SongList songs)
{
	// ������
	QTableWidget* table = ui.tableWidgetSong;
	table->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);

	// ��վ�����
	table->clear();
	searchResultPlayLists.clear();

	// ����Table����
	enum 
	{
		titleCol,
		artistCol,
		albumCol,
		durationCol
	};
	table->setColumnCount(4);
	QStringList headers{ QString::fromLocal8Bit("����"), QString::fromLocal8Bit("����"), QString::fromLocal8Bit("ר��"), QString::fromLocal8Bit("ʱ��") };
	table->setHorizontalHeaderLabels(headers);

	// �����г���
	QFontMetrics fm(font());
	int fw = fm.horizontalAdvance("һ�����������߰˾�ʮʮһʮ��ʮ��ʮ��ʮ��");
	auto createItem = [=](QString s) {
		QTableWidgetItem *item = new QTableWidgetItem();
		if (s.length() > 16 && fm.horizontalAdvance(s) > fw)
		{
			item->setToolTip(s);
			s = s.left(15) + "...";
		}
		item->setText(s);
		return item;
	};

	table->setRowCount(songs.size());
	for (int row = 0; row < songs.size(); row++)
	{
		Music song = songs.at(row);
		table->setItem(row, titleCol, createItem(song.name));
		table->setItem(row, artistCol, createItem(song.artistNames));
		table->setItem(row, albumCol, createItem(song.album.name));
		table->setItem(row, durationCol, createItem(msecondToString(song.duration)));
	}

	QTimer::singleShot(0, [=] 
	{
		table->horizontalHeader()->setSectionResizeMode(QHeaderView::Interactive);
	});
}

QString QtMusic::msecondToString(qint64 msecond)
{
	return QString("%1:%2").arg(msecond / 1000 / 60, 2, 10, QLatin1Char('0'))
		.arg(msecond / 1000 % 60, 2, 10, QLatin1Char('0'));
}

void QtMusic::slotTableWidgetSongDoubleClicked(int nRow, int nCol)
{
	int row = nRow;
	int index = nRow;
	Music currentsong;
	if (row > -1)
		currentsong = searchResultSongs.at(index);

	if (orderSongs.contains(currentsong))
		orderSongs.removeOne(currentsong);
	else
		orderSongs.insert(0, currentsong);

	playAfterDownloaded = currentsong;
	downloadSong(currentsong);
	playLocalSong(currentsong);

	if (!orderSongs.contains(currentsong))
		orderSongs.append(currentsong);
}

void QtMusic::downloadSong(Music music)
{
	downloadingSong = music;
	QString url = API_DOMAIN + "/song/url?id=" + snum(music.id);
	qDebug() << QString::fromLocal8Bit("��ȡ������Ϣ��") << music.simpleString();
	QNetworkAccessManager* manager = new QNetworkAccessManager;
	QNetworkRequest* request = new QNetworkRequest(url);
	request->setHeader(QNetworkRequest::ContentTypeHeader, "application/x-www-form-urlencoded; charset=UTF-8");
	request->setHeader(QNetworkRequest::UserAgentHeader, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36");
	connect(manager, &QNetworkAccessManager::finished, this, [=](QNetworkReply* reply)
	{
		QByteArray baData = reply->readAll();
		QJsonParseError error;
		QJsonDocument document = QJsonDocument::fromJson(baData, &error);
		if (error.error != QJsonParseError::NoError)
		{
			qDebug() << error.errorString();
			return;
		}
		QJsonObject json = document.object();
		if (json.value("code").toInt() != 200)
		{
			qDebug() << QString::fromLocal8Bit("���ؽ����Ϊ200��") << json.value("message").toString();
			return;
		}
		QJsonArray array = json.value("data").toArray();
		if (!array.size())
		{
			qDebug() << QString::fromLocal8Bit("δ�ҵ�������") << music.simpleString();
			downloadingSong = Music();  // ���
			downloadNext();
			return;
		}

		json = array.first().toObject();
		QString url = JVAL_STR(url);
		int br = JVAL_INT(br); // ����320000
		int size = JVAL_INT(size);
		QString type = JVAL_STR(type); // mp3
		QString encodeType = JVAL_STR(encodeType); // mp3
		qDebug() << QString::fromLocal8Bit(" ��Ϣ��" )<< br << size << type << encodeType << url;
		if (size == 0)
		{
			qDebug() << QString::fromLocal8Bit("����ʧ�ܣ� ����û�а�Ȩ") << music.simpleString();
			if (playAfterDownloaded == music)
			{
				if (orderSongs.contains(music))
				{
					orderSongs.removeOne(music);
					ui.playingNameLabel->clear();
					// ������Ϣ
					auto max16 = [=](QString s)
					{
						if (s.length() > 16)
							s = s.left(15) + "...";
						return s;
					};
					ui.playingNameLabel->setText(max16(music.name));
					ui.playingArtistLabel->setText(max16(music.artistNames));
					
					//  ���÷���
					if (QFileInfo(coverPath(music)).exists())
					{
						QPixmap pixmap(coverPath(music), "1");
						if (pixmap.isNull())
							qDebug() << QString::fromLocal8Bit("warning: ���ط����ǿյ�") << music.simpleString() << coverPath(music);
						// ����Ӧ�߶�
						pixmap = pixmap.scaledToHeight(ui.playingCoverLablel->height());
						ui.playingCoverLablel->setPixmap(pixmap);
					}
					else
						downloadSongCover(music);
					player->stop();
				}
			}
			downloadingSong = Music();
			downloadNext();
			return;
		}

		// ���ظ�������
		QNetworkAccessManager manager;
		QEventLoop loop;
		QNetworkReply *reply1 = manager.get(QNetworkRequest(QUrl(url)));
		// ���������������غ��˳����¼�ѭ��
		connect(reply1, &QNetworkReply::finished, &loop, &QEventLoop::quit);

		// �������¼�ѭ��
		loop.exec();
		QByteArray baData1 = reply1->readAll();

		QString strPath = songPath(music);
		QFile file(strPath);
		file.open(QIODevice::WriteOnly);
		file.write(baData1);
		file.flush();
		file.close();


		if (playAfterDownloaded == music)
			playLocalSong(music);

		downloadingSong = Music();
		downloadNext();
	});
	manager->get(*request);

	downloadSongLyric(music);
	downloadSongCover(music);
}

void QtMusic::downloadSongLyric(Music music)
{
	downloadingSong = music;
	QString url = API_DOMAIN + "/lyric?id=" + snum(music.id);
	QNetworkAccessManager* manager = new QNetworkAccessManager;
	QNetworkRequest* request = new QNetworkRequest(url);
	request->setHeader(QNetworkRequest::ContentTypeHeader, "application/x-www-form-urlencoded; charset=UTF-8");
	request->setHeader(QNetworkRequest::UserAgentHeader, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36");
	connect(manager, &QNetworkAccessManager::finished, this, [=](QNetworkReply* reply) {
		QByteArray baData = reply->readAll();
		QJsonParseError error;
		QJsonDocument document = QJsonDocument::fromJson(baData, &error);
		if (error.error != QJsonParseError::NoError)
		{
			qDebug() << error.errorString();
			return;
		}
		QJsonObject json = document.object();
		if (json.value("code").toInt() != 200)
		{
			qDebug() << ("���ؽ����Ϊ200��") << json.value("message").toString();
			return;
		}

		QString lrc = json.value("lrc").toObject().value("lyric").toString();
		if (!lrc.isEmpty())
		{
			QFile file(lyricPath(music));
			file.open(QIODevice::WriteOnly);
			QTextStream stream(&file);
			stream << lrc;
			file.flush();
			file.close();

			qDebug() << QString::fromLocal8Bit("���ظ����ɣ�") << music.simpleString();
		}
		else
			qDebug() << QString::fromLocal8Bit("warning: ���صĸ���ǿյ�") << music.simpleString();

	});
	manager->get(*request);
}

void QtMusic::downloadSongCover(Music music)
{
	if (QFileInfo(coverPath(music)).exists())
		return;
	downloadingSong = music;
	QString url = API_DOMAIN + "/song/detail?ids=" + snum(music.id);
	QNetworkAccessManager* manager = new QNetworkAccessManager;
	QNetworkRequest* request = new QNetworkRequest(url);
	request->setHeader(QNetworkRequest::ContentTypeHeader, "application/x-www-form-urlencoded; charset=UTF-8");
	request->setHeader(QNetworkRequest::UserAgentHeader, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36");
	connect(manager, &QNetworkAccessManager::finished, this, [=](QNetworkReply* reply) {
		QByteArray baData = reply->readAll();
		QJsonParseError error;
		QJsonDocument document = QJsonDocument::fromJson(baData, &error);
		if (error.error != QJsonParseError::NoError)
		{
			qDebug() << error.errorString();
			return;
		}
		QJsonObject json = document.object();
		if (json.value("code").toInt() != 200)
		{
			qDebug() << QString::fromLocal8Bit("���ؽ����Ϊ200��") << json.value("message").toString();
			return;
		}

		QJsonArray array = json.value("songs").toArray();
		if (!array.size())
		{
			qDebug() << QString::fromLocal8Bit("δ�ҵ�������") << music.simpleString();
			downloadingSong = Music();
			downloadNext();
			return;
		}

		json = array.first().toObject();
		QString url = json.value("al").toObject().value("picUrl").toString();
		qDebug() << QString::fromLocal8Bit("�����ַ��") << url;

		// ��ʼ���ظ�������
		static QNetworkAccessManager manager;
		static QEventLoop loop;
		QNetworkReply *reply1 = manager.get(QNetworkRequest(QUrl(url)));

		//���������������ɺ��˳����¼�ѭ��
		connect(reply1, &QNetworkReply::finished, &loop, &QEventLoop::quit);

		//�������¼�ѭ��
		loop.exec();

		QByteArray baData1 = reply1->readAll();
		QPixmap pixmap;
		pixmap.loadFromData(baData1);
		ui.playingCoverLablel->setPixmap(pixmap);
		if (!pixmap.isNull())
		{
			QFile file(coverPath(music));
			file.open(QIODevice::WriteOnly);
			file.write(baData1);
			file.flush();
			file.close();

			// ���ǵ�ǰҪ���ŵĸ���
			if (playAfterDownloaded == music || playingSong == music)
			{
				pixmap = pixmap.scaledToHeight(ui.playingCoverLablel->height());
				ui.playingCoverLablel->setPixmap(pixmap);
			}
		}
		else
		{
			qDebug() << QString::fromLocal8Bit("warning: ���صķ����ǿյ�") << music.simpleString();
		}
	});
	manager->get(*request);
}

/**
 * �������ض��С���һ�׸����ؽ�����������һ��
 */
void QtMusic::downloadNext()
{
	// �������صĸ��Ѿ�������/�������صĶ����ǿյ� bool 0 false 1 true
	if (downloadingSong.isValid() || !toDownLoadSongs.size())
		return;
	Music music = toDownLoadSongs.takeFirst();
	if (!music.isValid())
		return downloadNext();
	downloadSong(music);
}

QString QtMusic::coverPath(const Music &music) const
{
	return musicFileDir.absoluteFilePath(snum(music.id) + ".jpg");
}

QString QtMusic::lyricPath(const Music &music) const
{
	return musicFileDir.absoluteFilePath(snum(music.id) + ".lrc");
}

QString QtMusic::songPath(const Music &music) const
{
	return musicFileDir.absoluteFilePath(snum(music.id) + ".mp3");
}

/**
 * ������ʼ��������
 */
void QtMusic::playLocalSong(Music music)
{
	qDebug() << QString::fromLocal8Bit("��ʼ����") << music.simpleString();

	QString mi = music.simpleString();
	if (mi.length() > 6)
	{
		mi = mi.left(5) + "...";
	}
	else
		//music_info->setText(mi);
	//if (!isSongDownloaded(music))
	{
		qDebug() << QString::fromLocal8Bit("error:δ���ظ�����") << music.simpleString() << QString::fromLocal8Bit("��ʼ����");
		playAfterDownloaded = music;
		downloadSong(music);
		return;
	}

	// ������Ϣ
	auto max16 = [=](QString s) {
		if (s.length() > 16)
			s = s.left(15) + "...";
		return s;
	};
	ui.playingNameLabel->setText(max16(music.name));
	ui.playingArtistLabel->setText(max16(music.artistNames));
	ui.all_duration->setText(msecondToString(music.duration));
	//  ���÷���
	if (QFileInfo(coverPath(music)).exists())
	{
		QPixmap pixmap(coverPath(music), "1");
		if (pixmap.isNull())
			qDebug() << QString::fromLocal8Bit("warning: ���ط����ǿյ�") << music.simpleString() << coverPath(music);
		// ����Ӧ�߶�
		pixmap = pixmap.scaledToHeight(ui.playingCoverLablel->height());
		ui.playingCoverLablel->setPixmap(pixmap);
		//setCurrentCover(pixmap);
	}
	else
	{
		downloadSongCover(music);
	}

	// ����
	if (QFileInfo(lyricPath(music)).exists())
	{
		QFile file(lyricPath(music));
		file.open(QIODevice::ReadOnly | QIODevice::Text);
		QTextStream stream(&file);
		QString lyric;
		QString line;
		while (!stream.atEnd())
		{
			line = stream.readLine();
			lyric.append(line + "\n");
		}

		file.close();

	}
	else
	{
		//setCurrentLyric("");
		downloadSongLyric(music);
	}
	// ��ʼ����
	playingSong = music;
	player->setMedia(QUrl::fromLocalFile(songPath(music)));
	player->setPosition(0);
	player->play();
	//emit signalSongPlayStarted(music);
	setWindowTitle(music.name);

	// ���ӵ����ظ���
	if (localSongs.contains(music))
	{
		qDebug() << QString::fromLocal8Bit("���ظ������Ѵ��ڣ�") << music.simpleString();
		return;
	}
	else
	{
		localSongs.append(music);
	}



}

void QtMusic::slotPlayerPositionChanged()
{
	qint64 position = player->position();

	//if (ui->lyricWidget->setPosition(position))
	{
		QPropertyAnimation* ani = new QPropertyAnimation(this, "lyricScroll");
		//ani->setStartValue(ui->scrollArea->verticalScrollBar()->sliderPosition());
		//ani->setEndValue(qMax(0, ui->lyricWidget->getCurrentTop() - this->height() / 2));
		ani->setDuration(200);
		connect(ani, &QPropertyAnimation::valueChanged, this, [=] {
			//ui->scrollArea->verticalScrollBar()->setSliderPosition(lyricScroll);
		});
		connect(ani, SIGNAL(finished()), ani, SLOT(deleteLater()));
		ani->start();
	}
	ui.playProgressSlider->setSliderPosition(static_cast<int>(position));
	update();
}