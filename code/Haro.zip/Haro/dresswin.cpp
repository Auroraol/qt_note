#include "dresswin.h"
#include "ui_dresswin.h"
#include <QBitmap>
#include <QPainter>

DressWin::DressWin(QWidget* parent) :
    QWidget(parent),
    ui(new Ui::DressWin),
    y(0)
{
    ui->setupUi(this);
    setAutoFillBackground(true);
    setAttribute(Qt::WA_StyledBackground);   // 设置顶层窗口有效
    setWindowIcon(QIcon(":/images/icon/dress.png"));
    setWindowTitle("装扮");
    setWindowOpacity(0.90);//设置透明度
    // 保持窗口置顶 + 去除边框
    Qt::WindowFlags m_flags = windowFlags();
    setWindowFlags(m_flags | Qt::WindowStaysOnTopHint | Qt::FramelessWindowHint);
    //设置圆角边框
    QBitmap bmp(this->size());
    bmp.fill();
    QPainter p(&bmp);
    p.setPen(Qt::NoPen);
    p.setBrush(Qt::black);
    p.drawRoundedRect(bmp.rect(), 30, 30);
    setMask(bmp);
    initBtn();
}

DressWin::~DressWin()
{
    delete ui;
}

// 按钮初始化
void DressWin::initBtn()
{
    setStyleSheet("QPushButton{border:none;"
                  "background-color:rgb(200,200,200);"
                  "border-radius:15px;"
                  "border-style:outset;}"
                  "QPushButton::hover{background-color:rgb(170,200,255);}"
                  "QPushButton:checked{background-color:rgb(100,120,230);}");
    bodyBox =  new QButtonGroup;
    earsBox =  new QButtonGroup;
    bodyBox->setExclusive(true);  //在任何给定时间组中只能选中一个按钮
    earsBox->setExclusive(true);
    for(int i = 0; i < NUM; i++)
    {
        bodyBtn[i] = new QPushButton(this);
        bodyBtn[i]->setFixedSize(80, 40);
        bodyBtn[i]->move(80, i * 240 + 210);
        bodyBtn[i]->setIcon(QIcon(":/images/icon/choose.png"));
        bodyBtn[i]->setCheckable(1);  // 表示可以选中
        bodyBox->addButton(bodyBtn[i], i);
        earsBtn[i] = new QPushButton(this);
        earsBtn[i]->setFixedSize(80, 40);
        earsBtn[i]->move(280, i * 240 + 210);
        earsBtn[i]->setIcon(QIcon(":/images/icon/choose.png"));
        earsBtn[i]->setCheckable(1);
        earsBox->addButton(earsBtn[i], i);
    }
    connect(bodyBox, SIGNAL(buttonClicked(int)), this, SLOT(bodyChange(int)));
    connect(earsBox, SIGNAL(buttonClicked(int)), this, SLOT(earsChange(int)));
}

void DressWin::bodyChange(int id)
{
    emit bodyChangeNum(id);
}

void DressWin::earsChange(int id)
{
    emit earsChangeNum(id);
}

void DressWin::accept(std::vector<QPixmap>& body, std::vector<QPixmap>& ears, int bodyNum, int earsNum)
{
    this->body = body;
    this->ears = ears;
    bodyBtn[bodyNum]->setChecked(1);  // 选中
    earsBtn[earsNum]->setChecked(1);
}

// 画图
void DressWin::paintEvent(QPaintEvent*)
{
    static QPixmap dummy(":/images/appearance/body/dummy.png");
    static QPixmap dummy2(":/images/appearance/dress.png");
    QPainter painter(this);
    painter.drawPixmap(0, 0, dummy2.scaled(450, 530));  // 显示背景图
    for(int i = 0; i < NUM; i++)
    {
        painter.drawPixmap(0, y + i * 240, 240, 240, body[i]);
    }
    for(int i = 0; i < NUM; i++)
    {
        painter.drawPixmap(200, y + i * 240, 240, 240, dummy);
        painter.drawPixmap(200, y + i * 240, 240, 240, ears[i]);
    }
}

void DressWin::wheelEvent(QWheelEvent* ev)
{
    if (ev->angleDelta().y() > 0)  // 前滚
    {
        if(y < 0)
        {
            y += 40;   //
        }
    }
    else
    {
        if(y > -230 * NUM + 460)
        {
            y -= 40;
        }
    }
    for(int i = 0; i < NUM; i++)
    {
        bodyBtn[i]->move(80, y + i * 240 + 210);
        earsBtn[i]->move(280, y + i * 240 + 210);
    }
    update();//更新绘画事件
}
