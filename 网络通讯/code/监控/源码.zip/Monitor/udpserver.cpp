#include "udpserver.h"
#define UDP_SERVER_PORT 44446
#define UDP_CLIENT_PORT 44448

UdpServer::UdpServer(QObject *parent)
	: QObject(parent)
{
	socket_ = new QUdpSocket(this);
	socket_->bind(UDP_SERVER_PORT,QUdpSocket::ShareAddress);
	connect(socket_, SIGNAL(readyRead()), this, SLOT(readPendingDatagrams()));

	connect(&timer_, SIGNAL(timeout()), this, SLOT(udpTimeOut()));
	timer_.start(5000);
}

UdpServer::~UdpServer()
{
}

void UdpServer::readPendingDatagrams()
{
	while (socket_->hasPendingDatagrams()) {
		QByteArray datagram;
		datagram.resize(socket_->pendingDatagramSize());
		QHostAddress sender;
		quint16 senderPort;
		socket_->readDatagram(datagram.data(), datagram.size(),&sender, &senderPort);
		processTheDatagram(datagram);
	}
}

void UdpServer::processTheDatagram(QByteArray &data)
{

	if (data.length() >= 3)
	{
		int offset = 1;
		char header;
		char tail;
		QByteArray intbytes = data.left(offset);
		memcpy(&header, intbytes.data(), intbytes.size());

		intbytes = data.right(1);
		memcpy(&tail, intbytes.data(), intbytes.size());

		if (header == 'H' && tail == 'T')
		{
			char type;
			intbytes = data.mid(offset, 1);
			memcpy(&type, intbytes.data(), intbytes.size());
			offset += 1;

			if (type == 'L')//�����������
			{
				//isLocker
				char isLocker;
				intbytes = data.mid(offset, 1);
				memcpy(&isLocker, intbytes.data(), intbytes.size());
				offset += 1;
				
				if (isLocker == 'Y')
				{
					emit lockMouseSignal(true);
				}
				else if (isLocker == 'N')
				{
					emit lockMouseSignal(false);
				}
			}
			else if (type == 'R')
			{
			
			}
		}
	}

}

void UdpServer::udpTimeOut()
{
	if (socket_)
	{
		QByteArray data;
		data.append("ZX");
		socket_->writeDatagram(data, QHostAddress::Broadcast, UDP_CLIENT_PORT);
	}
}
