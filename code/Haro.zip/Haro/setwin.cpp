#include "setwin.h"
#include "ui_setwin.h"
#include <QBitmap>
#include <QPainter>
#include <QDebug>
#include <QSettings>

SetWin::SetWin(QWidget* parent) :
    QWidget(parent),
    ui(new Ui::SetWin)
{
    ui->setupUi(this);
    setWindowIcon(QIcon(":/images/icon/setting.png"));
    setWindowTitle("设置");
    setWindowOpacity(0.97);//设置透明度
    // 保持窗口置顶 + 去除边框
    Qt::WindowFlags m_flags = windowFlags();
    setWindowFlags(m_flags | Qt::WindowStaysOnTopHint | Qt::FramelessWindowHint);
    //设置圆角边框
    QBitmap bmp(this->size());
    bmp.fill();
    QPainter p(&bmp);
    p.setPen(Qt::NoPen);
    p.setBrush(Qt::black);
    p.drawRoundedRect(bmp.rect(), 20, 20);
    setMask(bmp);
}

SetWin::~SetWin()
{
    delete ui;
}

void SetWin::on_sizeSlider_valueChanged(int value)
{
    haroSize = value;
    ui->label_size->setNum(value);  //显示
    emit getSize(value);
}

void SetWin::setSize(int size)
{
    haroSize = size;
    ui->label_size->setNum(haroSize);
    ui->sizeSlider->setValue(haroSize);
}



void SetWin::on_openBox_stateChanged(int arg1)
{
    //点击: 2 未点击: 0
    SetMyAppAutoRun(arg1);
}

void SetWin::SetMyAppAutoRun(bool isstart)
{
    //NativeFormat在windows下就是系统注册
    QSettings nsettings("HKEY_CURRENT_USER\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run",
                        QSettings::NativeFormat) ;
    qDebug() << nsettings.allKeys();
    QString napppath = QApplication::applicationFilePath();
    QString nappname = QApplication::applicationName();
    napppath = napppath.replace("/", "\\");
    if(isstart)
    {
        nsettings.setValue(nappname, napppath);
    }
    else
    {
        nsettings.remove(nappname);
    }
}

