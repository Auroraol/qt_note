#ifndef SETWIN_H
#define SETWIN_H

#include <QWidget>

namespace Ui
{
    class SetWin;
}

class SetWin : public QWidget
{
    Q_OBJECT

public:
    explicit SetWin(QWidget* parent = nullptr);
    ~SetWin();
    void setSize(int size);

private slots:
    void on_sizeSlider_valueChanged(int value);

    void on_openBox_stateChanged(int arg1);

signals:
    void getSize(int haroSize);

private:
    Ui::SetWin* ui;
    int haroSize;   //haro大小

    void SetMyAppAutoRun(bool isstart); //开机启动
};

#endif // SETWIN_H
