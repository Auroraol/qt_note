#ifndef CLIENT_H
#define CLIENT_H

#include <QtWidgets/QMainWindow>
#include "ui_client.h"
#include <QTcpSocket>
#include <QMutex>
#include <QPixMap>
#include <QUdpSocket>
#include <QDateTime>
#include <QTimer>

class Client : public QMainWindow
{
	Q_OBJECT

public:
	Client(QWidget *parent = 0);
	~Client();

private:
	Ui::ClientClass ui;

	QTcpSocket* socket_;

	bool isConnected_;

	QByteArray receiveData_;

	QPixmap showPic_;

	QUdpSocket* udpSocket_;

	QMap<QString, QDateTime> serverIpMap_;

	QTimer timer_;

	bool isRecord_;
private:
	void connectServer(QString ip);

	void processData();
	void processTheDatagram(QByteArray &datagram,QString ip,quint32 port);
	QString formatIP(QString ip);
	void setList();
	void udpSendData(QString ip,const QByteArray &data);
public slots:
	void readFortune();
	void displayError(QAbstractSocket::SocketError socketError);
	void stateChanged(QAbstractSocket::SocketState socketState);

	void readPendingDatagrams();
	void on_list_dbclicked(const QModelIndex& index);
	void serverTimeOut();
	void on_connect_clicked();

	void on_record_clicked();
	void on_playback_clicked();
	void on_getPic_clicked();
	void on_lockMouse_clicked();
	void on_unLockMouse_clicked();
};

#endif // CLIENT_H
