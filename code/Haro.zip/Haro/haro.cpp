#include "haro.h"
#include "ui_haro.h"
#include <QCommonStyle>
#include <QScreen>
#include <QTimer>
#include <QDebug>
#include <QTime>
#include <QTextCharFormat>


Haro::Haro(QWidget* parent)
    : QWidget(parent),
      ui(new Ui::Haro),
      m_trayMenu(new QMenu),
      m_tray(new QSystemTrayIcon(this)),
      setWindow(new SetWin),
      dressWindow(new DressWin),
      musicWindow(new OneMusic),
      calenWindow(new QCalendarWidget),
      gameWindow(new GameWin),
      aboutWindow(new About)
{
    ui->setupUi(this);
    qsrand((unsigned int)time(NULL));
    setWindowFlags(Qt::FramelessWindowHint | Qt::Tool); //去掉窗口边框,和任务栏图标
    setAttribute(Qt::WA_TranslucentBackground);//设置背景透明
//    this->setWindowIcon(QIcon(":/images/icon/haro_icon.ico"));
    Qt::WindowFlags m_flags = windowFlags();
    setWindowFlags(m_flags | Qt::WindowStaysOnTopHint);
    loadSettings();
    addSystemTray();
    initHaro();
    connect(setWindow, &SetWin::getSize, this, &Haro::changeSize);  // setWindow设置大小改变
    connect(this, &Haro::getSize, this, &Haro::sizeUpdate);  // 滚轮设置大小改变
}

Haro::~Haro()
{
    delete ui;
}

// 初始化Haro
void Haro::initHaro()
{
    loadImage();
    initBtn();
    imageSet(ui->label_body_Image, body[bodyNum]);  // 默认第一张图
    imageSet(ui->label_ears_Image, ears1[earsNum]);
    imageSet(ui->label_eyes_Image, eyes);
    if(size > 140)
    {
        imageSet(ui->label_stripe_Image, stripe);
    }
    // 特殊表情
    imageSet(ui->label_fly_image, spMovement[11]);
    ui->label_fly_image->hide();
    // 定时器
    QTimer* timer = new QTimer(this);
    timer->start(40); // 4/100 = 0.04s
    connect(timer, &QTimer::timeout, this, &Haro::animation);
}

void Haro::loadSettings()
{
    QString filePath = qApp->applicationDirPath() + "/config.ini" ;
    settings = new QSettings(filePath, QSettings::IniFormat);
    settings->beginGroup("LOCATION");
    int x = settings->value("x").toInt();
    int y = settings->value("y").toInt();
    size = settings->value("size").toInt();
    if (size == 0)
    {
        size = 400;
    }
    bodyNum = settings->value("bodyNum").toInt();
    earsNum = settings->value("earsNum").toInt();
    settings->endGroup();
    QRect targRect = QRect(x, y, 0, 0);
    QRect clientRect = QGuiApplication::primaryScreen()->availableVirtualGeometry();
    QRect targRect0 = QRect(clientRect.width() / 4, clientRect.height() / 4, clientRect.width() / 2, clientRect.height() / 2);
    //如果上一次关闭软件的时候，窗口位置不正常，则本次显示在显示器的正中央
    if(x < 0 || x > clientRect.width() || y < 0 || y > clientRect.height())
    {
        targRect = targRect0;
    }
    this ->move(targRect.x(), targRect.y());
//    this->resize(size, size);
}

void Haro::saveSettings()
{
    settings->clear();//清空当前配置文件中的内容
    settings->beginGroup("LOCATION");
    settings->setValue("x", this->x());
    settings->setValue("y", this->y());
    settings->setValue("size", size);
    settings->setValue("bodyNum", bodyNum);
    settings->setValue("earsNum", earsNum);
    settings->endGroup();
}

void Haro::loadImage()
{
    loadIAressmage(); // 加载装饰图片
    loadImageAnimationImage(); //加载动画图片
    specialMovementLoad(); // 加载erro图片
}

// 加载装饰图片
void Haro::loadIAressmage()
{
    //载入装扮图片
    body.push_back(QPixmap(":/images/appearance/body/def_body.png"));
    body.push_back(QPixmap(":/images/appearance/body/blue_body.png"));
    body.push_back(QPixmap(":/images/appearance/body/pink_body.png"));
    body.push_back(QPixmap(":/images/appearance/body/icefire_body.png"));
    body.push_back(QPixmap(":/images/appearance/body/cat_body.png"));
    body.push_back(QPixmap(":/images/appearance/body/Gundam_body.png"));
    body.push_back(QPixmap(":/images/appearance/body/drill_body.png"));
    body.push_back(QPixmap(":/images/appearance/body/angel_body.png"));
    ears1.push_back(QPixmap(":/images/appearance/ears/def_ears1.png"));
    ears1.push_back(QPixmap(":/images/appearance/ears/blue_ears1.png"));
    ears1.push_back(QPixmap(":/images/appearance/ears/pink_ears1.png"));
    ears1.push_back(QPixmap(":/images/appearance/ears/icefire_ears1.png"));
    ears1.push_back(QPixmap(":/images/appearance/ears/cat_ears1.png"));
    ears1.push_back(QPixmap(":/images/appearance/ears/Gundam_ears1.png"));
    ears1.push_back(QPixmap(":/images/appearance/ears/drill_ears1.png"));
    ears1.push_back(QPixmap(":/images/appearance/ears/angel_ears1.png"));
    ears2.push_back(QPixmap(":/images/appearance/ears/def_ears2.png"));
    ears2.push_back(QPixmap(":/images/appearance/ears/blue_ears2.png"));
    ears2.push_back(QPixmap(":/images/appearance/ears/pink_ears2.png"));
    ears2.push_back(QPixmap(":/images/appearance/ears/icefire_ears2.png"));
    ears2.push_back(QPixmap(":/images/appearance/ears/cat_ears2.png"));
    ears2.push_back(QPixmap(":/images/appearance/ears/Gundam_ears2.png"));
    ears2.push_back(QPixmap(":/images/appearance/ears/drill_ears2.png"));
    ears2.push_back(QPixmap(":/images/appearance/ears/angel_ears2.png"));
    eyes.load(":/images/appearance/eyes/def_eyes.png");
    stripe.load(":/images/appearance/stripe.png");
}

// 设置图片(设置大小和位置)
void Haro::imageSet(QLabel* image, QPixmap map)
{
    //根据size设定各图片大小和坐标
    image->setPixmap(map.scaled(size, size)); //使用scaled修改图片大小，能避免图片因缩放模糊
    image->setScaledContents(true);
    image->resize(size, size); //设置label的尺寸
    // 居中显示
    image->move(this->frameGeometry().width() / 2 - size / 2,
                this->frameGeometry().height() / 2 - size / 2);
}

// 系统托盘
void Haro::addSystemTray()
{
    QCommonStyle style;
    m_trayMenu->addAction(QIcon(style.standardPixmap(QStyle::SP_ComputerIcon)), "打开主界面");
    m_trayMenu->addAction(QIcon(style.standardPixmap(QStyle::SP_MessageBoxInformation)), "关于");
    m_trayMenu->addAction(QIcon(style.standardPixmap(QStyle::SP_DialogCancelButton)), "退出");
    //托盘加入菜单
    m_tray->setToolTip("OneHaro");
    m_tray->setIcon(QIcon(":/images/icon/haro_icon.ico"));
    m_tray->setContextMenu(m_trayMenu);
    //绑定托盘小图标点击事件
    connect(m_tray, SIGNAL(activated(QSystemTrayIcon::ActivationReason)), this, SLOT(OnSystemTrayClicked(QSystemTrayIcon::ActivationReason)));
    //菜单子项触发
    connect(m_trayMenu, SIGNAL(triggered(QAction*)), this, SLOT(actionTriggered(QAction*)));
    m_tray->show(); //显示小图标
}

//点击了任务栏托盘小图标
void Haro::OnSystemTrayClicked(QSystemTrayIcon::ActivationReason reason)
{
    switch (reason)
    {
        case QSystemTrayIcon::Trigger:
            this->showNormal();
            break;
        default:
            break;
    }
}

void Haro::actionTriggered(QAction* action)
{
    if(action->text() == "打开主界面")
    {
        this->showNormal();
    }
    else if(action->text() == "退出")
    {
        this->hide();
        saveSettings();//写入设置
        qApp->exit(0);
    }
    else if (action->text() == "关于")
    {
        aboutWindow->show();
    }
}

// 初始化按钮
void Haro::initBtn()
{
    // 设置图片
    ui->pushButton_closeBtn->setIcon(QIcon(":/images/icon/close.png"));
    ui->pushButton_dressBtn->setIcon(QIcon(":/images/icon/dress.png"));
    ui->pushButton_moreBtn->setIcon(QIcon(":/images/icon/more.png"));
    ui->pushButton_minBtn->setIcon(QIcon(":/images/icon/min.png"));
    ui->pushButton_setBtn->setIcon(QIcon(":/images/icon/setting.png"));
    ui->pushButton_musicBtn->setIcon(QIcon(":/images/icon/music.png"));
    ui->pushButton_gameBtn->setIcon(QIcon(":/images/icon/game.png"));
    ui->pushButton_calenBtn->setIcon(QIcon(":/images/icon/calendar.png"));
    // 设置图大小
    buttonSize();
    // 不显示
    ui->pushButton_calenBtn->setVisible(false);
    ui->pushButton_gameBtn->setVisible(false);
    ui->pushButton_musicBtn->setVisible(false);
    ui->pushButton_setBtn->setVisible(false);
    //日历
    calenWindow->setWindowTitle("日历");
    calenWindow->setWindowIcon(QIcon(":/images/icon/calendar.png"));
    Qt::WindowFlags m_flags = windowFlags();
    calenWindow->setWindowFlags(m_flags | Qt::WindowStaysOnTopHint | Qt::FramelessWindowHint);
    calenWindow->setFirstDayOfWeek(Qt::Sunday);
    calenWindow->setWeekdayTextFormat(Qt::Saturday, calenWindow->weekdayTextFormat(Qt::Monday));  // 将周六日的颜色去掉
    calenWindow->setWeekdayTextFormat(Qt::Sunday, calenWindow->weekdayTextFormat(Qt::Monday));
    calenWindow->setVerticalHeaderFormat(QCalendarWidget::NoVerticalHeader); //去掉列表头
    calenWindow->setHorizontalHeaderFormat(QCalendarWidget::LongDayNames);  //星期使用长的名字
    calenWindow->resize(600, 400);
    setqssstyle(":/qss/calen.qss");
    // 装扮
    dressWindow->accept(body, ears1, bodyNum, earsNum);
    connect(dressWindow, &DressWin::bodyChangeNum, this, [&](int id)
    {
        bodyNum = id;
        ui->label_body_Image->setPixmap(body[id].scaled(size, size));
    });
    connect(dressWindow, &DressWin::earsChangeNum, this, [&](int id)
    {
        earsNum = id;
        ui->label_body_Image->setPixmap(body[id].scaled(size, size));
    });
}

void Haro::buttonSize()
{
    btnSize = size;
    if(btnSize < 200)//限制按钮大小
    {
        btnSize = 200;
    }
    // 设置图大小
    QSize temp(btnSize / 8, btnSize / 8);  //50 X 50
    ui->pushButton_closeBtn->setIconSize(temp);
    ui->pushButton_dressBtn->setIconSize(temp);
    ui->pushButton_moreBtn->setIconSize(temp);
    ui->pushButton_minBtn->setIconSize(temp);
    ui->pushButton_setBtn->setIconSize(temp);
    ui->pushButton_musicBtn->setIconSize(temp);
    ui->pushButton_gameBtn->setIconSize(temp);
    ui->pushButton_calenBtn->setIconSize(temp);
    //按钮的坐标和大小参数
    int btnX = this->frameGeometry().width() / 2 - btnSize * 3 / 5 - 5;
    int btnY = this->frameGeometry().height() / 2 - btnSize / 4;
    int btnWidth = btnSize / 5;
    int btnHeight = btnSize / 8;  // 矩形: 80 X 50
    ui->pushButton_closeBtn->setGeometry(btnX, btnY, btnWidth, btnHeight);
    ui->pushButton_dressBtn->setGeometry(btnX, btnY + btnSize / 6, btnWidth, btnHeight);
    ui->pushButton_moreBtn->setGeometry(btnX, btnY + 2 * btnSize / 6, btnWidth, btnHeight);
    ui->pushButton_minBtn->setGeometry(btnX, btnY + 3 * btnSize / 6, btnWidth, btnHeight);
    ui->pushButton_setBtn->setGeometry(btnX - btnWidth * 1.2, btnY, btnWidth, btnHeight);
    ui->pushButton_musicBtn->setGeometry(btnX - btnWidth * 1.2, btnY + btnSize / 6, btnWidth, btnHeight);
    ui->pushButton_gameBtn->setGeometry(btnX - btnWidth * 1.2, btnY + 2 * btnSize / 6, btnWidth, btnHeight);
    ui->pushButton_calenBtn->setGeometry(btnX - btnWidth * 1.2, btnY + 3 * btnSize / 6, btnWidth, btnHeight);
}

//加载动画图片
void Haro::loadImageAnimationImage()
{
    faceNum.push_back(9);//一个表情的图片个数
    faceNum.push_back(0);//起始索引
    for(int i = 1; i <= 9; i++) //表情1-眨眼
    {
        //起始索引: 0
        movement.push_back(QPixmap(QString(":/images/movement/blink/%1.png").arg(i)));
    }
    faceNum.push_back(12);
    faceNum.push_back(9);
    for(int i = 1; i <= 12; i++) //表情2-心动
    {
        //起始索引: 9
        movement.push_back(QPixmap(QString(":/images/movement/heart/%1.png").arg(i)));
    }
    faceNum.push_back(16);
    faceNum.push_back(21);
    for(int i = 1; i <= 16; i++) //表情3-疑惑
    {
        //起始索引: 21
        movement.push_back(QPixmap(QString(":/images/movement/question/%1.png").arg(i)));
    }
    faceNum.push_back(15);
    faceNum.push_back(37);
    for(int i = 1; i <= 15; i++) //表情4-闭眼
    {
        //起始索引:37
        movement.push_back(QPixmap(QString(":/images/movement/closeEyes/%1.png").arg(i)));
    }
    faceNum.push_back(9);
    faceNum.push_back(52);
    for(int i = 1; i <= 9; i++)  //表情5-单眨眼
    {
        //起始索引: 52
        movement.push_back(QPixmap(QString(":/images/movement/wink/%1.png").arg(i)));
    }
    face = -1;
    faceSum = 5;
}

//动画--->画图
void Haro::animation()
{
    static int second1 = 0,  second2 = 0;
    static int count = 0;
    //特殊动作
    if(spMove == 0)
    {
        specialMovement();
    }
    else
    {
        //控制眨眼动作
        //随机开始播放默认眼部表情 && 循环
        int valve = qrand() % 200;
        if(face < 0)
        {
            second1++;
            if(second1 >= valve && valve > 100)
            {
                face = 0;
                second1 = 0;
            }
        }
        //控制表情变化-->其实就是处理数组
        if (face != -1)
        {
            // 默认情况随机循环画表情1
            int num = faceNum[face * 2], start = faceNum[face * 2 + 1];  // 偶数 奇数
            if (count < num)
            {
                //闭眼 //movement[起始索引 + i]
                ui->label_eyes_Image->setPixmap(movement[start + count].scaled(size, size));
            }
            else
            {
                //睁眼
                ui->label_eyes_Image->setPixmap(movement[start - count + (num - 1) * 2].scaled(size, size));
            }
            if(count >= (num - 1) * 2)
            {
                count = 0;
                face = -1;  // 停会儿
                ui->label_eyes_Image->setPixmap(eyes.scaled(size, size));
            }
            count++;
        }
    }
    //控制耳朵的动画
    second2++;
    if(second2 > 10 && second2 < 40)
    {
        ui->label_ears_Image->setPixmap(ears1[earsNum].scaled(size, size));
    }
    else if(second2 > 40)
    {
        ui->label_ears_Image->setPixmap(ears2[earsNum].scaled(size, size));
        second2 = 0;
    }
}

// 加载erro图片
void Haro::specialMovementLoad()
{
    for(int i = 1; i <= 11; i++)
    {
        spMovement.push_back(QPixmap(QString(":/images/movement/error/%1.png").arg(i)));
    }
    for(int i = 1; i <= 22; i++)
    {
        spMovement.push_back(QPixmap(QString(":/images/movement/fly/%1.png").arg(i)));
    }
    spMove = -1;
}

// TODO
void Haro::specialMovement()
{
    static int specialCount = 0;
    if(spMove == 0) //动作-error
    {
        ui->label_fly_image->show();
        //count % 20 == 0才换图的原因是拉长换图间隔, 定时器是0.04s进入一次的
        if(specialCount % 20 == 0 && specialCount <= 200)
        {
            ui->label_eyes_Image->setPixmap(spMovement[specialCount / 20].scaled(size, size)); // 使用平滑的缩放方式);  // 显示错误信息
        }
        // TODO
//        if (specialCount % 5 == 0 && specialCount <= 200)
//        {
//            // 12-32
//            ui->label_fly_image->setPixmap(spMovement[specialCount / 5 + 12].scaled(size, size));
//        }
        else if(specialCount > 300)
        {
            // 复原
            ui->label_fly_image->hide();
            ui->label_eyes_Image->setPixmap(eyes.scaled(size, size));
            specialCount = 0;
            spMove = -1;
            return;
        }
    }
    specialCount++;
}

// 事件
void Haro::mousePressEvent(QMouseEvent* ev)
{
    // 按下换表情
    if(ev->button() == Qt::LeftButton)
    {
        m_bDrag = true;
        mouseStartPoint = ev->globalPos();  //获得鼠标的初始位置
        windowTopLeftPoint = this->frameGeometry().topLeft();    //获得窗口的初始位置
        //当前状态没有播放表情就 随机播放其他表情
        if(face < 0 && spMove < 0)
        {
//            随机触发个蓝屏
            int temp = qrand() % 100;
            if (temp == 10 || temp == 50)
            {
                spMove = 0;
                face = -1;
            }
            else
            {
                face = qrand() % (faceSum - 1) + 1;    // [1, size)
            }
        }
    }
    else if(ev->button() == Qt::RightButton)
    {
        if (!setWindow->isHidden())
        {
            setWindow->setVisible(false);
        }
        if (!calenWindow->isHidden())
        {
            calenWindow->setVisible(false);
        }
        if (!musicWindow->isHidden())
        {
            musicWindow->setVisible(false);
        }
        if (!dressWindow->isHidden())
        {
            dressWindow->setVisible(false);
        }
        if (!gameWindow->isHidden())
        {
            gameWindow->setVisible(false);
        }
        static int a, b;
        //隐藏基础按钮
        if (!ui->pushButton_closeBtn->isHidden() && !ui->pushButton_calenBtn->isHidden())
        {
            a = 1;
            //qDebug() << a;
            ui->pushButton_closeBtn->setVisible(false);
            ui->pushButton_dressBtn->setVisible(false);
            ui->pushButton_moreBtn->setVisible(false);
            ui->pushButton_minBtn->setVisible(false);
            //
            ui->pushButton_calenBtn->setVisible(false);
            ui->pushButton_gameBtn->setVisible(false);
            ui->pushButton_musicBtn->setVisible(false);
            ui->pushButton_setBtn->setVisible(false);
        }
        else if (a == 1 && ui->pushButton_closeBtn->isHidden() && ui->pushButton_calenBtn->isHidden())
        {
            a = 0;
            //qDebug() << a;
            ui->pushButton_closeBtn->setVisible(true);
            ui->pushButton_dressBtn->setVisible(true);
            ui->pushButton_moreBtn->setVisible(true);
            ui->pushButton_minBtn->setVisible(true);
            //
            ui->pushButton_calenBtn->setVisible(true);
            ui->pushButton_gameBtn->setVisible(true);
            ui->pushButton_musicBtn->setVisible(true);
            ui->pushButton_setBtn->setVisible(true);
        }
        else if (!ui->pushButton_closeBtn->isHidden() && ui->pushButton_calenBtn->isHidden())
        {
            b = 1;
            ui->pushButton_closeBtn->setVisible(false);
            ui->pushButton_dressBtn->setVisible(false);
            ui->pushButton_moreBtn->setVisible(false);
            ui->pushButton_minBtn->setVisible(false);
        }
        else if (b == 1 && ui->pushButton_closeBtn->isHidden() && ui->pushButton_calenBtn->isHidden())
        {
            b = 0;
            ui->pushButton_closeBtn->setVisible(true);
            ui->pushButton_dressBtn->setVisible(true);
            ui->pushButton_moreBtn->setVisible(true);
            ui->pushButton_minBtn->setVisible(true);
        }
    }
}

void Haro::mouseMoveEvent(QMouseEvent* ev)
{
    if(ev->buttons() & Qt::LeftButton)//鼠标左键按下并移动时，实现拖动窗口
    {
        if(m_bDrag)
        {
            //获得鼠标移动的距离
            QPoint distance = ev->globalPos() - mouseStartPoint;
            //改变窗口的位置
            this->move(windowTopLeftPoint + distance);
            //
            dressWindow->move(x() + frameGeometry().width() / 2 - 10
                              - btnSize * 0.6 - dressWindow->frameGeometry().width(),
                              y() + frameGeometry().height() / 2 - 150
                              - dressWindow->frameGeometry().height() / 2);
            musicWindow->move(x() + frameGeometry().width() / 2
                              - btnSize * (2 + 1.5) / 4 - musicWindow->frameGeometry().width(),
                              y() + frameGeometry().height() / 2 - size / 5
                              - musicWindow->frameGeometry().height() / 2);
            calenWindow->move(x() + frameGeometry().width() / 2
                              - btnSize * (2 + 1.5) / 4 - calenWindow->frameGeometry().width(),
                              y() + frameGeometry().height() / 2 - size / 5
                              - calenWindow->frameGeometry().height() / 2);
            setWindow->move(x() + frameGeometry().width() / 2
                            - btnSize * (2 + 1.5) / 4 - setWindow->frameGeometry().width(),
                            y() + frameGeometry().height() / 2 - size / 5
                            - setWindow->frameGeometry().height() / 2);
            gameWindow->move(x() + frameGeometry().width() / 2
                             - btnSize * (2  + 1.5) / 4 - musicWindow->frameGeometry().width(),
                             y() + frameGeometry().height() / 2 - size / 5
                             - musicWindow->frameGeometry().height() / 2);
        }
    }
}

void Haro::mouseReleaseEvent(QMouseEvent* event)
{
    if(event->button() == Qt::LeftButton)
    {
        m_bDrag = false;
    }
}

void Haro::wheelEvent(QWheelEvent* ev)
{
    if (ev->modifiers() == Qt::ControlModifier && !ev->angleDelta().isNull())  // 使用ctrl + 滚轮放大
    {
        emit getSize(ev->angleDelta().y());
    }
}

void Haro::closeEvent(QCloseEvent* event)
{
//    if(event->type() == QEvent::Close)
//    {
//        event->ignore();
//    }
    saveSettings();
}

void Haro::on_pushButton_closeBtn_clicked()
{
    setWindow->close();
    calenWindow->close();
    musicWindow->close();
    dressWindow->close();
    gameWindow->close();
    this->close();  // 调用closeEvent
}

//TODO
void Haro::on_pushButton_dressBtn_clicked()
{
    // 新窗口
    if(dressWindow->isHidden())
    {
        dressWindow->move(x() + frameGeometry().width() / 2 - 10
                          - btnSize * 0.6 - dressWindow->frameGeometry().width(),
                          y() + frameGeometry().height() / 2 - 150
                          - dressWindow->frameGeometry().height() / 2);
        dressWindow->show();  // 装扮窗口显示
        setWindow->hide();
        musicWindow->hide();
        calenWindow->hide();
        if (!ui->pushButton_calenBtn->isHidden())
        {
            ui->pushButton_calenBtn->setVisible(false);
            ui->pushButton_gameBtn->setVisible(false);
            ui->pushButton_musicBtn->setVisible(false);
            ui->pushButton_setBtn->setVisible(false);
        }
    }
    else
    {
        dressWindow->hide();
    }
}

void Haro::on_pushButton_moreBtn_clicked()
{
    if (!dressWindow->isHidden())
    {
        dressWindow->hide();
    }
    if ( ui->pushButton_calenBtn->isHidden())
    {
        ui->pushButton_calenBtn->setVisible(true);
        ui->pushButton_gameBtn->setVisible(true);
        ui->pushButton_musicBtn->setVisible(true);
        ui->pushButton_setBtn->setVisible(true);
    }
    else
    {
        ui->pushButton_calenBtn->setVisible(false);
        ui->pushButton_gameBtn->setVisible(false);
        ui->pushButton_musicBtn->setVisible(false);
        ui->pushButton_setBtn->setVisible(false);
    }
}

void Haro::on_pushButton_minBtn_clicked()
{
    this->showMinimized();  // 最小化
    setWindow->hide();
    calenWindow->hide();
    musicWindow->hide();
    dressWindow->hide();
    gameWindow->hide();
}

void Haro::on_pushButton_setBtn_clicked()
{
    // 新窗口
    if(setWindow->isHidden())
    {
        //移动窗口坐标↓
        setWindow->move(x() + frameGeometry().width() / 2
                        - btnSize * (2 + 1.5) / 4 - setWindow->frameGeometry().width(),
                        y() + frameGeometry().height() / 2 - size / 5
                        - setWindow->frameGeometry().height() / 2);
        setWindow->setSize(size);
        setWindow->show();
        dressWindow->hide();
        musicWindow->hide();
        calenWindow->hide();
        gameWindow->hide();
    }
    else
    {
        setWindow->hide();
    }
}

//TODO
void Haro::on_pushButton_musicBtn_clicked()
{
    // 新窗口
    if(musicWindow->isHidden())
    {
        //移动窗口坐标↓
        musicWindow->move(x() + frameGeometry().width() / 2
                          - btnSize * (2  + 1.5) / 4 - musicWindow->frameGeometry().width(),
                          y() + frameGeometry().height() / 2 - size / 5
                          - musicWindow->frameGeometry().height() / 2);
        musicWindow->show();
        setWindow->hide();
        calenWindow->hide();
        dressWindow->hide();
        gameWindow->hide();
    }
    else
    {
        musicWindow->hide();
    }
}

void Haro::on_pushButton_gameBtn_clicked()
{
    // 新窗口
    if (gameWindow->isHidden())
    {
        gameWindow->move(x() + frameGeometry().width() / 2
                         - btnSize * (2  + 1.5) / 4 - musicWindow->frameGeometry().width(),
                         y() + frameGeometry().height() / 2 - size / 5
                         - musicWindow->frameGeometry().height() / 2);
        gameWindow->show();
        musicWindow->hide();
        setWindow->hide();
        calenWindow->hide();
        dressWindow->hide();
    }
    else
    {
        gameWindow->hide();
    }
}

void Haro::on_pushButton_calenBtn_clicked()
{
    // 新窗口
    if(calenWindow->isHidden())
    {
        //移动窗口坐标↓
        calenWindow->move(x() + frameGeometry().width() / 2
                          - btnSize * (2 + 1.5) / 4 - calenWindow->frameGeometry().width(),
                          y() + frameGeometry().height() / 2 - size / 5
                          - calenWindow->frameGeometry().height() / 2);
        calenWindow->show();
        musicWindow->hide();
        setWindow->hide();
        dressWindow->hide();
        gameWindow->hide();
    }
    else
    {
        calenWindow->hide();
    }
}

//设置css功能函数
void Haro::setqssstyle(const QString& qssFile)
{
    QFile file(qssFile);
    if (!file.open(QFile::ReadOnly))
    {
        qDebug() << "Failed to load the style file";
        return;
    }
    QString qss = QLatin1String(file.readAll());
    calenWindow->setStyleSheet(qss);
    //设置 Qt：调色板QPalette类
    QString PaletteColor = qss.mid(20, 7);
    calenWindow->setPalette(QPalette(QColor(PaletteColor)));
    file.close();
}

void Haro::changeSize(int value)
{
    //  重新设置窗口大小
    size = value;
    imageSet(ui->label_body_Image, body[bodyNum]);
    imageSet(ui->label_ears_Image, ears1[earsNum]);
    imageSet(ui->label_eyes_Image, eyes);
    if(size > 140)
    {
        imageSet(ui->label_stripe_Image, stripe);
    }
    else
    {
        ui->label_stripe_Image->hide();
    }
    buttonSize();
}

void Haro::sizeUpdate(int value)
{
    //  重新设置窗口大小
    size += value;
    if (size  < 60)
    {
        size = 60;
        return;
    }
    imageSet(ui->label_body_Image, body[bodyNum]);
    imageSet(ui->label_ears_Image, ears1[earsNum]);
    imageSet(ui->label_eyes_Image, eyes);
    if(size > 140)
    {
        imageSet(ui->label_stripe_Image, stripe);
    }
    else
    {
        ui->label_stripe_Image->hide();
    }
    buttonSize();
}
