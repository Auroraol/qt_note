#include "client.h"
#include <QtWidgets/QApplication>
#include <QTextCodec>
#include <QTextStream>
#include <QFileInfo>

int main(int argc, char *argv[])
{
	QString appPath;
	QTextCodec *xcodec = QTextCodec::codecForLocale();
	QString exeDir = xcodec->toUnicode(QByteArray(argv[0]));
	appPath = QFileInfo(exeDir).path();

	QString strPluginPath = appPath + QString::fromLocal8Bit("/plugins");
	QCoreApplication::addLibraryPath(strPluginPath);

	QApplication a(argc, argv);
	Client w;
	w.show();
	return a.exec();
}
