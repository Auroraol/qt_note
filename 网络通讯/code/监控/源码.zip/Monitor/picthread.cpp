#include "picthread.h"
#include <QtGui/QPixmap>
#include <QApplication>
#include <QDesktopWidget>
#include <QBuffer>
#include <QDebug>
#include <QMutex>

QMutex g_bufferLocker_;
QList<QByteArray> g_BufferList_;

PicThread::PicThread(QObject *parent)
	: QThread(parent)
{
	screen_ = QApplication::primaryScreen();
}

PicThread::~PicThread()
{

}

void PicThread::run()
{
	while (true)
	{
		msleep(100);
		QByteArray sendArray;
		bool isok = getPic(sendArray);
		if (isok)
		{
			g_bufferLocker_.lock();
			if (g_BufferList_.size() > 10)
			{
				qDebug() << "size too long.. remove one.";
				g_BufferList_.clear();
			}
			g_BufferList_.append(sendArray);
			g_bufferLocker_.unlock();
		}
		else
		{
			qDebug() << "get pic error.";
		}
	}
}


bool PicThread::getPic(QByteArray& result)
{

	QPixmap pic = screen_->grabWindow(0);
	QBuffer buffer(&result);
	buffer.open(QIODevice::WriteOnly);
	bool isok = pic.save(&buffer, "jpg");

	return isok;
}
