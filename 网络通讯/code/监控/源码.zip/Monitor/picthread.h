#ifndef PICTHREAD_H
#define PICTHREAD_H

#include <QThread>
#include <QtGui/QScreen>

class PicThread : public QThread
{
	Q_OBJECT

public:
	PicThread(QObject *parent = NULL);
	~PicThread();

	void run();

private:
	bool getPic(QByteArray& result);

private:
	QScreen *screen_;
};

#endif // PICTHREAD_H
