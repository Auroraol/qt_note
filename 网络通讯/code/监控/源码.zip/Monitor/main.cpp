
#include <QtCore/QCoreApplication>
#include <QApplication>
#include "picthread.h"
#include "server.h"
#include "udpserver.h"
#include <QTextCodec>
#include <QTextStream>
#include <QFileInfo>

int main(int argc, char *argv[])
{
	QString appPath;
	QTextCodec *xcodec = QTextCodec::codecForLocale();
	QString exeDir = xcodec->toUnicode(QByteArray(argv[0]));
	appPath = QFileInfo(exeDir).path();

	QString strPluginPath = appPath + QString::fromLocal8Bit("/plugins");
	QCoreApplication::addLibraryPath(strPluginPath);

	QApplication a(argc, argv);

	UdpServer *udp = new UdpServer();

	PicThread *picThread = new PicThread();
	picThread->start();

	Server* server = new Server();
	QObject::connect(udp, SIGNAL(lockMouseSignal(bool)), server, SLOT(lockerMouseSlot(bool)));


	return a.exec();
}
